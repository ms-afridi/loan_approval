End to End Deployment

Loan Approval Prediction

1. Dataset
2. Dataset (jupyter source file)
3. .Pkl Model file for algorithm and Scaling
4. flask application.py is to connect the backend with frontend
5. Template (html) for frontend